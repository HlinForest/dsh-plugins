# 电路设计 0.3.3 七步验证证据

运行日期：2026-10-14；证据同步日期：2026-10-15。

在已安装的 0.3.3 原生独立窗口中新建显示板项目，七步均通过界面操作确认，真实生成并下载 KiCad 工程。第二步及后续步骤均保留第一步的确认状态与输出哈希；刷新后七步仍已确认。共 21 个页签、1 个项目、28 类工程内容比较一致。

模型响应 12 次，全部为模拟；真实模型调用为零。生成工具实际运行。第 3–7 步明确选择带待确认项继续草稿；最终 ERC 1 条、DRC 40 条待复核，仍缺规格书等证据。此轮未执行空目录重放，也不代表正式工程签核或真实模型质量验证。

七步完成后的网页下载事件观察超时，原生下载实际成功。随后在同一项目以 Electron 原生事件验证下载并刷新，未重新生成或确认。细节见 verification.json 的 testDriverNote。

- verification.json：完整结果、实现哈希、包哈希、待确认项。
- step-results.json：逐步输出与确认。
- ui-actions.json：真实页面创建、保存、执行和确认请求。
- progress.json：处理进度与第一步状态观察。
- artifact-checks.json：生成工程 ZIP 哈希、文件数、网表检查。
- screenshots/：本次实际界面截图。

<run> 表示本机隔离验证目录。证据包不包含生成工程本体、账号、登录、窗口会话密钥、用户配置或模型凭据。

安装包与验证所用插件完全一致，170 个包内文件逐一比对通过；本次不重新构建插件。

升级与实际加载核对：https://github.com/HlinForest/dsh-plugins/blob/main/docs/update-eda-flow-0.3.3.md

可重跑脚本：https://github.com/HlinForest/dsh-plugins/blob/main/plugins/dsh-eda-flow/test/desktop-seven-steps.mjs
