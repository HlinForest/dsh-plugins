import type { Catalog, SearchResult, Source } from './domain.js';
export type SolutionReport = {
    schemaVersion: 1;
    reportId: string;
    generatedAt: string;
    title: string;
    requestText: string;
    language: 'zh-CN';
    writingStyle: string;
    catalog: {
        dataset: string;
        version: string;
        revision: string;
        demo: boolean;
    };
    analysis: SearchResult;
    sources: Source[];
    catalogSnapshot: Catalog;
    conclusion: {
        qualified: string[];
        pending: string[];
        excluded: number;
        scope: string;
    };
    nextActions: string[];
};
export declare function buildSolutionReport(catalog: Catalog, analysis: SearchResult, requestText: string, title?: string): SolutionReport;
export declare function reportMarkdown(report: SolutionReport): string;
export declare function reportHTML(report: SolutionReport, outputPath?: string): string;
export declare function exportReport(report: SolutionReport, directory: string): Promise<{
    reportId: string;
    markdown: string;
    jsonPath: string;
    markdownPath: string;
    htmlPath: string;
    links: {
        markdown: string;
        href: string;
    }[];
}>;
export declare function compactResult(result: SearchResult): {
    candidates: {
        checks: {
            source: {
                id: string;
                version: string;
                location: string;
            } | null;
            constraintId: string;
            field: import("./domain.js").Field;
            label: string;
            hard: boolean;
            expected: string;
            actual: string;
            status: "pass" | "fail" | "unknown";
            reason: string;
            quote: string;
            supportingEvidence?: import("./domain.js").Evidence[];
            page?: number;
        }[];
        productId: string;
        productName: string;
        family: string;
        status: "matches_listed_constraints" | "needs_confirmation" | "incompatible";
        score: number;
        documents?: Source[];
        power?: {
            ratedW?: number;
            verifiedContinuousW?: number;
            peakW?: number;
            peakDurationS?: number;
            temperatureC?: number;
            basis: string;
        };
    }[];
    sources: {
        links: import("./domain.js").SourceLink[];
        id: string;
        title: string;
        version: string;
        location: string;
        url?: string;
        file?: string;
        line?: number;
        sha256?: string;
        page?: number;
    }[];
    dataset: string;
    catalogVersion: string;
    demo: boolean;
    humanReviewRequired: true;
    requirements: import("./domain.js").RequirementResult;
    totalEvaluated: number;
    totalCandidates: number;
    excludedIncompatible: number;
    catalogRevision?: string;
};
