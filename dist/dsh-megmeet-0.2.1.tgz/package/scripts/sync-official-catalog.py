"""Snapshot the complete public Megmeet download listing, without demo data or guessed specifications.

Requires requests and beautifulsoup4. Existing --snapshot can replay the downloaded response.
Document URLs never retain temporary OSS signatures. PDF reading renews those URLs from the website.
"""
import argparse, collections, datetime, hashlib, json, pathlib, re, unicodedata
from urllib.parse import urljoin, urlsplit, urlunsplit, quote, unquote
import requests
from bs4 import BeautifulSoup

ROOT = pathlib.Path(__file__).resolve().parents[1]
PAGE = 'https://www.megmeet.com/service'
API = 'https://www.megmeet.com/Service/getlist.html'

def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()[:20]

def stable_url(url):
    url = urljoin(PAGE, url)
    parts = urlsplit(url)
    if parts.hostname == 'megmeet-official-website.oss-cn-hangzhou.aliyuncs.com':
        return urlunsplit((parts.scheme, parts.netloc, parts.path, '', ''))
    return url

def model_names(title):
    # Preserve exact printed identifiers. Do not expand a wildcard or invent variants from power ratings.
    text = unicodedata.normalize('NFKC', title)
    text = re.split(r'用户|手册|宣传|证书|认证|说明|操作|安装|编程|软件|指导|图纸|(?<![A-Za-z0-9])[23]D|使用|选型|规格|接口|接线|快速|参数|系列|电机|变频器|驱动器|产品', text)[0]
    tokens = re.findall(r'(?<![A-Za-z0-9_(])(?:[A-Za-z][A-Za-z0-9_.*+~/-]*)', text)
    result = []
    for token in tokens:
        token = re.sub(r'\.(?:pdf|xml|zip|rar|edz|stp|step|dwg)$', '', token, flags=re.I)
        token = re.split(r'_SIZE|_Size|_V(?=\d)', token)[0].rstrip('-_./')
        if not re.search(r'\d', token) and token not in ('MDBU', 'ESPCP', 'MetaTig', 'Dex', 'Artsen', 'Ehave', 'WepeX'):
            continue
        if re.match(r'^(?:V\d|EN\d|IEC\d|ISO\d|GB\d|UL\d|CERT|CE\d|X_Builder|Builder|Solution|RS232|RS485|G1|SP2)', token, re.I):
            continue
        result.append(token)
    return sorted(set(result))

def build(payload, output):
    if payload.get('status') != 1 or not isinstance(payload.get('html'), str):
        raise ValueError('Official download listing did not return a successful response')
    soup = BeautifulSoup(payload['html'], 'html.parser')
    items = []
    for row in soup.select('.item'):
        title = row.select_one('.title')
        view, download = row.select_one('a.view'), row.select_one('a.download')
        anchor = view or download
        if not title or not anchor:
            continue
        raw_url = anchor.get('data-url') or anchor.get('href')
        if not raw_url:
            continue
        title = title.get_text(' ', strip=True)
        url = stable_url(raw_url)
        if urlsplit(url).scheme not in ('http', 'https'):
            raise ValueError('Unexpected official download URL')
        date = row.select_one('.time')
        decoded_path = unquote(urlsplit(url).path)
        parts = decoded_path.split('/')
        family = parts[3] if len(parts) > 4 and parts[1] == 'file' else '官网资料'
        items.append({'id': 'megmeet-' + digest(url), 'title': title, 'url': url, 'officialPage': PAGE,
                      'revision': date.get_text(strip=True) if date else '未提供',
                      'format': pathlib.PurePosixPath(decoded_path).suffix.lower().lstrip('.'),
                      'family': family, 'models': model_names(title)})
    expected = int(re.search(r'\d+', payload['count']).group())
    if len(items) != expected:
        raise ValueError(f'Incomplete listing: parsed {len(items)}, website reports {expected}')
    documents = {}
    models = {}
    for item in items:
        if item['id'] not in documents:
            documents[item['id']] = {**item, 'titles': [item['title']]}
        else:
            doc = documents[item['id']]
            doc['titles'] = sorted(set(doc['titles'] + [item['title']]))
            doc['models'] = sorted(set(doc['models'] + item['models']))
        for model in item['models']:
            entry = models.setdefault(model.upper(), {'name': model, 'family': item['family'], 'documentIds': []})
            entry['documentIds'] = sorted(set(entry['documentIds'] + [item['id']]))
    now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
    coverage = {'officialPage': PAGE, 'endpoint': API, 'filters': {'gid': '', 'pid': '', 'id': '', 'sid': ''},
                'fetchedAt': now, 'listedRows': expected, 'uniqueDocuments': len(documents), 'namedModelsAndSeries': len(models),
                'listingComplete': True, 'specificationExtractionComplete': False,
                'scope': '官网全部类型下载列表。型号/系列来自资料标题原文；通配符不展开，手册内部未逐项提取的子型号不冒充已核验。所有资料均保留。'}
    index = {'schemaVersion': 1, 'id': 'megmeet-official', 'label': '麦格米特官网全部下载资料', 'coverage': coverage, 'items': list(documents.values())}
    sources = [{'id': d['id'], 'title': d['title'], 'version': d['revision'], 'location': '官网资料下载条目；工程参数尚未逐项核验。',
                'url': PAGE + '?key=' + quote(d['models'][0] if d['models'] else d['title'])} for d in documents.values()]
    products = [{'id': m['name'], 'name': m['name'], 'manufacturer': 'MEGMEET', 'family': m['family'],
                 'description': '官网资料标题收录的型号/系列；具体规格与子型号需打开原件核对。', 'parameters': {}, 'evidence': {},
                 'documentIds': m['documentIds'], 'catalogEntryKind': 'model-or-series'} for m in models.values()]
    catalog = {'schemaVersion': 2, 'dataset': '麦格米特官网型号与系列资料索引', 'version': 'OFFICIAL-' + now[:10],
               'demo': False, 'coverage': coverage, 'sources': sources, 'products': sorted(products, key=lambda p: p['id'])}
    output.mkdir(parents=True, exist_ok=True)
    for filename, value in [('download-index.json', index), ('catalog.json', catalog)]:
        (output / filename).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(coverage, ensure_ascii=False))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--snapshot', type=pathlib.Path)
    parser.add_argument('--output', type=pathlib.Path, default=ROOT / 'official')
    args = parser.parse_args()
    if args.snapshot:
        payload = json.loads(args.snapshot.read_text(encoding='utf-8'))
    else:
        response = requests.post(API, data={'gid': '', 'pid': '', 'id': '', 'sid': ''}, headers={'X-Requested-With': 'XMLHttpRequest', 'Referer': PAGE}, timeout=90)
        response.raise_for_status()
        payload = response.json()
    build(payload, args.output)
