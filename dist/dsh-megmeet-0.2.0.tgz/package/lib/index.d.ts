import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
export declare const name = "megmeet-product-assistant";
export declare const inject: string[];
export interface Config {
    catalogPath: string;
    maxCandidates: number;
    maxInputChars: number;
    reportDirectory: string;
}
export declare const Config: Schema<Config>;
export declare function apply(ctx: Context, config: Config): Promise<void>;
