import type { Catalog, Evidence, Product, RequirementResult } from './domain.js';
export type ContinuousPower = {
    watts?: number;
    temperatureC?: number;
    reason: string;
    evidence?: Evidence;
};
export declare function continuousPower(catalog: Catalog, product: Product, requirements: RequirementResult): ContinuousPower;
