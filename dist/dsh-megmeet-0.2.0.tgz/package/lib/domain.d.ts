export declare const FIELDS: {
    readonly input_voltage_v: {
        readonly label: "输入电压";
        readonly unit: "V";
        readonly kind: "number";
        readonly aliases: readonly ["输入电压", "input voltage"];
    };
    readonly output_voltage_v: {
        readonly label: "输出电压";
        readonly unit: "V";
        readonly kind: "number";
        readonly aliases: readonly ["输出电压", "output voltage"];
    };
    readonly output_power_w: {
        readonly label: "输出功率";
        readonly unit: "W";
        readonly kind: "number";
        readonly aliases: readonly ["输出功率", "额定功率", "output power", "rated power"];
    };
    readonly output_channels: {
        readonly label: "输出路数";
        readonly unit: "路";
        readonly kind: "number";
        readonly aliases: readonly ["输出路数", "output channels", "number of outputs"];
    };
    readonly output_current_a: {
        readonly label: "输出电流";
        readonly unit: "A";
        readonly kind: "number";
        readonly aliases: readonly ["输出电流", "output current"];
    };
    readonly input_frequency_hz: {
        readonly label: "输入频率";
        readonly unit: "Hz";
        readonly kind: "number";
        readonly aliases: readonly ["输入频率", "input frequency"];
    };
    readonly width_mm: {
        readonly label: "本体宽度";
        readonly unit: "mm";
        readonly kind: "number";
        readonly aliases: readonly ["本体宽度", "电源宽度", "width"];
    };
    readonly mounting: {
        readonly label: "安装方式";
        readonly unit: "";
        readonly kind: "text";
        readonly aliases: readonly ["安装方式", "mounting"];
    };
    readonly dc_ok: {
        readonly label: "DC OK继电器";
        readonly unit: "";
        readonly kind: "text";
        readonly aliases: readonly ["DC OK继电器", "DC-OK relay"];
    };
    readonly peak_power_w: {
        readonly label: "峰值功率";
        readonly unit: "W";
        readonly kind: "number";
        readonly aliases: readonly ["峰值功率", "peak power"];
    };
    readonly peak_duration_s: {
        readonly label: "峰值持续时间";
        readonly unit: "s";
        readonly kind: "number";
        readonly aliases: readonly ["峰值持续时间", "peak duration"];
    };
    readonly continuous_load_w: {
        readonly label: "持续负载";
        readonly unit: "W";
        readonly kind: "number";
        readonly aliases: readonly ["持续负载", "continuous load"];
    };
    readonly power_margin_pct: {
        readonly label: "设计裕量";
        readonly unit: "%";
        readonly kind: "number";
        readonly aliases: readonly ["设计裕量", "power margin"];
    };
    readonly orientation: {
        readonly label: "安装姿态";
        readonly unit: "";
        readonly kind: "text";
        readonly aliases: readonly ["安装姿态", "orientation"];
    };
    readonly altitude_m: {
        readonly label: "海拔";
        readonly unit: "m";
        readonly kind: "number";
        readonly aliases: readonly ["海拔", "altitude"];
    };
    readonly top_clearance_mm: {
        readonly label: "上方间距";
        readonly unit: "mm";
        readonly kind: "number";
        readonly aliases: readonly ["上方间距", "top clearance"];
    };
    readonly bottom_clearance_mm: {
        readonly label: "下方间距";
        readonly unit: "mm";
        readonly kind: "number";
        readonly aliases: readonly ["下方间距", "bottom clearance"];
    };
    readonly side_clearance_mm: {
        readonly label: "侧面间距";
        readonly unit: "mm";
        readonly kind: "number";
        readonly aliases: readonly ["侧面间距", "side clearance"];
    };
    readonly efficiency_pct: {
        readonly label: "效率";
        readonly unit: "%";
        readonly kind: "number";
        readonly aliases: readonly ["转换效率", "效率", "efficiency"];
    };
    readonly temperature_c: {
        readonly label: "工作温度";
        readonly unit: "°C";
        readonly kind: "number";
        readonly aliases: readonly ["工作温度", "环境温度", "operating temperature", "ambient temperature"];
    };
    readonly protocols: {
        readonly label: "通信协议";
        readonly unit: "";
        readonly kind: "list";
        readonly aliases: readonly ["通信协议", "通讯协议", "通信接口", "通讯接口", "protocols", "protocol", "interfaces"];
    };
    readonly certifications: {
        readonly label: "认证";
        readonly unit: "";
        readonly kind: "list";
        readonly aliases: readonly ["认证", "certifications", "certification"];
    };
    readonly cooling: {
        readonly label: "散热方式";
        readonly unit: "";
        readonly kind: "text";
        readonly aliases: readonly ["散热方式", "冷却方式", "cooling"];
    };
    readonly input_type: {
        readonly label: "输入类型";
        readonly unit: "";
        readonly kind: "text";
        readonly aliases: readonly ["输入类型", "input type"];
    };
    readonly output_type: {
        readonly label: "输出类型";
        readonly unit: "";
        readonly kind: "text";
        readonly aliases: readonly ["输出类型", "output type"];
    };
};
export type Field = keyof typeof FIELDS;
export type Operator = 'gte' | 'lte' | 'eq' | 'range' | 'includes';
export type ConstraintInput = {
    field: Field;
    operator: Operator;
    value?: number;
    min?: number;
    max?: number;
    textValue?: string;
    hard?: boolean;
    sourceQuote: string;
};
export type Constraint = ConstraintInput & {
    id: string;
    hard: boolean;
    origin: 'rule' | 'provided' | 'derived';
};
export type PowerCalculation = {
    loadW: number;
    marginPct: number;
    requiredContinuousW: number;
    sourceQuotes: string[];
};
export type RequirementResult = {
    constraints: Constraint[];
    unresolved: string[];
    warnings: string[];
    calculations?: PowerCalculation[];
};
type Span = {
    min: number;
    max: number;
};
export type Parameter = number | Span | string | string[];
export type SourceLink = {
    kind: 'official' | 'snapshot';
    href: string;
    markdown: string;
};
export type Source = {
    id: string;
    title: string;
    version: string;
    location: string;
    /** Administrator-provided public document or landing page, never inferred by the model. */
    url?: string;
    /** Local original; relative paths are resolved against the catalog JSON directory. */
    file?: string;
    line?: number;
    sha256?: string;
    page?: number;
    /** Generated from validated addresses; preserve these links in the final chat answer. */
    links?: SourceLink[];
};
export type Evidence = {
    sourceId: string;
    quote: string;
    page?: number;
};
export type PowerProfile = Evidence & {
    points: {
        temperatureC: number;
        powerW: number;
    }[];
    inputMinV: number;
    inputMaxV: number;
    orientation: string;
    maxAltitudeM: number;
    clearancesMm: {
        top: number;
        bottom: number;
        side: number;
    };
    basis: 'rated_continuous';
    conditionsEvidence?: Evidence[];
};
export type Product = {
    id: string;
    name: string;
    family: string;
    description: string;
    parameters: Partial<Record<Field, Parameter>>;
    evidence: Partial<Record<Field, Evidence>>;
    manufacturer?: string;
    continuousPowerProfile?: PowerProfile;
    widthToleranceMm?: number;
};
export type Catalog = {
    schemaVersion: 1 | 2;
    dataset: string;
    version: string;
    demo: boolean;
    sources: Source[];
    products: Product[];
    /** Hash of the exact administrator-provided JSON bytes, generated at load. */
    revision?: string;
};
export type Check = {
    constraintId: string;
    field: Field;
    label: string;
    hard: boolean;
    expected: string;
    actual: string;
    status: 'pass' | 'fail' | 'unknown';
    reason: string;
    source: Source | null;
    quote: string;
    supportingEvidence?: Evidence[];
    page?: number;
};
export type Candidate = {
    productId: string;
    productName: string;
    family: string;
    status: 'matches_listed_constraints' | 'needs_confirmation' | 'incompatible';
    score: number;
    checks: Check[];
    power?: {
        ratedW?: number;
        verifiedContinuousW?: number;
        peakW?: number;
        peakDurationS?: number;
        temperatureC?: number;
        basis: string;
    };
};
export type SearchResult = {
    dataset: string;
    catalogVersion: string;
    demo: boolean;
    humanReviewRequired: true;
    requirements: RequirementResult;
    candidates: Candidate[];
    totalEvaluated: number;
    totalCandidates: number;
    excludedIncompatible: number;
    catalogRevision?: string;
};
/** Validate admin-provided catalog data before any product is offered to an agent. */
export declare function validateCatalog(data: unknown): Catalog;
export declare function loadCatalog(path: string, signal?: AbortSignal): Promise<Catalog>;
/** Rules provide a conservative first extraction; model additions must quote the input. */
export declare function parseRequirements(text: string, additions?: ConstraintInput[], maxChars?: number): RequirementResult;
export declare function validateCandidate(catalog: Catalog, requirements: RequirementResult, productId: string): Candidate;
export declare function searchProducts(catalog: Catalog, requirements: RequirementResult, options?: {
    family?: string;
    limit?: number;
    includeIncompatible?: boolean;
}): SearchResult;
/** DSH rc.2 accepts ordinary HTTPS links and absolute file paths with optional #L<n>. */
export declare function sourceLinks(source: Source): SourceLink[];
export declare function generateReport(result: SearchResult, title?: string): {
    markdown: string;
    demo: boolean;
    humanReviewRequired: true;
};
export {};
