import type { ConstraintInput } from './domain.js';
export type BusinessConfig = {
    catalogPath: string;
    maxCandidates: number;
    maxInputChars: number;
    reportDirectory: string;
};
export type BusinessArgs = {
    text?: string;
    constraints?: ConstraintInput[];
    family?: string;
    limit?: number;
    includeIncompatible?: boolean;
    productId?: string;
    productIds?: string[];
    title?: string;
    expectedCatalogRevision?: string;
};
export type BusinessCommand = 'info' | 'parse' | 'search' | 'validate' | 'report' | 'export';
export declare function executeBusiness(command: BusinessCommand, args: BusinessArgs, config: BusinessConfig, signal?: AbortSignal): Promise<any>;
